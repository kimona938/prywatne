<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Practice 🪄</title>
    <link rel="icon" href="./favicon.svg">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            background-color: gainsboro;
            font-family: Arial, Helvetica, sans-serif;
            letter-spacing: 0.05rem;
            font-size: 13px;
            height: 100vh;
        }

        mark{
            padding: 0.2rem;
        }

        header {
            height: 10%;
            width: 100%;
            text-align: justify;
            padding: 0.5rem 0 0 1rem;
        }

        main {
            display: flex;
            justify-content: space-evenly;
            align-items: center;
            flex-wrap: wrap;
            padding: 1rem;
            gap: 1rem;
            min-height: 85%;
            max-width: 100%;
        }

        form {
            background-color: lightgray;
            display: flex;
            max-height: min-content;
            min-width: 75%;
            border: 2px dashed black;
            flex-direction: column;
            gap: 0.3rem;
            padding: 1rem;
        }

        form input:not(input[type='checkbox']),
        select {
            padding: 0.3rem;
            width: 100%;
        }

        label:has(input[type='checkbox'], input[type='radio']){
            display: inline-block;
            white-space: nowrap;
            vertical-align: middle;
            padding: 0.5rem;
        }
        label input:not(input[type='date']){
            transform: scale(1.2);
            vertical-align: top;
        }

        textarea {
            padding: 0.35rem;
            font-family: Arial, Helvetica, sans-serif;
        }

        span {
            display: flex;
            justify-content: space-evenly;
            width: 100%;
        }

        button {
            width: 100%;
            padding: 0.5rem;
        }
        ul {
            padding-top: 1rem;
            padding-left: 1rem;
        }
    </style>
    <script defer>
        document.addEventListener("DOMContentLoaded", () => {
            if (localStorage.getItem('database') !== 'ok') {
                let res
                while (!(res = prompt("Before starting, please load `database.sql` into your phpmyadmin. \nType understood to close this window.") === 'understood')) {
                    localStorage.setItem('database', 'ok');
                }
            }
        })
    </script>
</head>

<body>
    <?php $conn = mysqli_connect("localhost", "root", "", "php_practice"); ?>
    <header>
        <h2>PHP Practice 🐘</h2>
        <p>Page is dedicated to learn sending / receiving data between pages in PHP.</p>
        <p>Additionally pages will include exercises with MySQLi queries.</p>
        <p><a class="special_link" href='https://github.com/TEB-DK/Domena_aplikacji_internetowych/blob/J%C4%99zyk-PHP/2.%20Obs%C5%82uga%20MySQLi.md'>Feel free to use this repository.</a></p>
    </header>
    <hr>
    <main>
        <!-- p1 -->
        <form action='exercise/p1.php' method='POST'>
            <h3>p1. Send user data form 🙂</h3>
            <input type="text" name="name" id="name" placeholder="Your name">
            <input type="text" name="surname" id="surname" placeholder="Your surname">
            <label for="terms">
                <input type="checkbox" id="terms">
                Do you agree to <a href="terms.php">terms and conditions</a>?
            </label>
            <span>
                <button>Send</button>
                <button type="reset">Reset</button>
            </span>
        </form>
        <!-- p2 -->
        <form action='exercise/p2.php' method='POST'>
            <h3>p2. Send location of user 💀</h3>
            <input type="text" name="name" id="name" placeholder="Your name">
            <select type="text" name="country" id="country">
                <option>Poland</option>
                <option>Germany</option>
                <option>Russia</option>
                <option>Hungary</option>
                <option>Lativa</option>
            </select>
            <span>
                <button>Send</button>
                <button type="reset">Reset</button>
            </span>
        </form>
        <!-- p3 -->
        <form action='exercise/p3.php' method='POST'>
            <h3>p3. Choose user gender form 👪</h3>
            <span>
                <label for="Men">
                    Men <input type="radio" name="gender" value="Man">
                </label>
                <label for="Women">
                    Women <input type="radio" name="gender" value="Woman">
                </label>
                <label for="Other">
                    Other <input type="radio" name="gender" value="Other">
                </label>
                <label for="Rather not say">
                    Rather not say <input type="radio" name="gender" value="Rather not say">
                </label>
            </span>
            <span>
                <button>Send</button>
            </span>
        </form>
        <!-- p4 -->
        <form action='exercise/p4.php' method='POST'>
            <h3>p4. Validate user form 🧮</h3>
            <input type="text" placeholder="Name here" name="name">
            <input type="text" placeholder="Surname here" name="surname">
            <label for="terms">
                <input type="checkbox" id="terms" name="terms">
                Do you agree to <a href="terms.php">terms and conditions</a>?
            </label>
            <span>
                <button>Send</button>
                <button type="reset">Reset</button>
            </span>
        </form>
        <!-- p5 -->
        <form action='exercise/p5.php' method='POST' id="p5">
            <h3>p5. Create user in database ⚙️</h3>
            <input type="text" name="first_name" id="first_name" placeholder="Your name">
            <input type="text" name="last_name" id="last_name" placeholder="Your surname">
            <input type="email" name="email" id="email" placeholder="E-mail here">
            <input type="text" name="student_index" id="student_index" placeholder="Student index">
            <span>
                <button>Send</button>
            </span>
        </form>
        <!-- p6 -->
        <form action='exercise/p6.php' method='POST' id="p6">
            <h3>p6. Add excercise to database ➕</h3>
            <label for="user_id">
                User:
                <select name="user_id" id="user_id">
                    <?php
                    $sql = "SELECT id, first_name FROM users";

                    $result = mysqli_query($conn, $sql);
                    if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                            $user_id = $row["id"];
                            $first_name = $row["first_name"];

                            echo "<option value='$user_id'>$first_name</option>";
                        }
                    } else {
                        echo "<option value='null'>No students in database.</option>";
                    }
                    ?>
                </select>
            </label>
            <input type="text" name="title" id="title" placeholder="Task title">
            <input type="text" name="subject" id="subject" placeholder="Subject of task">
            <textarea name="description" id="description" placeholder="Task description"></textarea>
            <label for="due_date">
                Due date:
                <input type="date" name="due_date" id="due_date">
            </label>
            <label for="stauts">
                Status:
                <select name="status" id="status">
                    <option value="unfinished">unfinished</option>
                    <option value="in_progress">in progress</option>
                    <option value="finished">finished</option>
                </select>
            </label>
            <span>
                <button>Add</button>
            </span>
        </form>
        <!-- p7 -->
        <form action="index.php#p7" method="GET" id="p7">
            <h3>p7. Display user and their exercises from database 😶‍🌫️</h3>
            <select name="user_id" id="user_id">
                <?php
                $sql = "SELECT id, first_name FROM users";

                $result = mysqli_query($conn, $sql);
                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $user_id = $row["id"];
                        $first_name = $row["first_name"];

                        echo "<option value='$user_id'>$first_name</option>";
                    }
                } else {
                    echo "<option value='null'>No students in database.</option>";
                }
                ?>
            </select>
            <span>
                <button>Show</button>
            </span>
            <?php include "exercise/p7.php"; ?>
        </form>
        <!-- p8 -->
        <form action="exercise/p8.php" method="POST" id="p8">
            <h3>p8. Delete user with their exercise ⚠️</h3>
            <select name="user_id" id="user_id">
                <?php
                $sql = "SELECT id, first_name FROM users";

                $result = mysqli_query($conn, $sql);
                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        $user_id = $row["id"];
                        $first_name = $row["first_name"];

                        echo "<option value='$user_id'>$first_name</option>";
                    }
                } else {
                    echo "<option value='null'>No students in database.</option>";
                }
                ?>
                </select>
            <span>
                <button>Delete</button>
            </span>
        </form>

    </main>
</body>

</html>
